package Exceptions;

public class ArgumentsException extends Error
{
    public ArgumentsException(String message)
    {
        super(message);
    }
}
