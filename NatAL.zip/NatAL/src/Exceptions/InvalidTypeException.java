package Exceptions;

public class InvalidTypeException extends Error {
    public InvalidTypeException(String message) {
        super(message);
    }
}
