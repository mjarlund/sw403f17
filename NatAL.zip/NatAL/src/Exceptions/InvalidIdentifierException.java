package Exceptions;

public class InvalidIdentifierException extends Error
{
    public InvalidIdentifierException(String message)
    {
        super(message);
    }
}
