package Exceptions;

public class DuplicatedSymbolException extends Error
{
    public DuplicatedSymbolException(String message)
    {
        super(message);
    }
}
