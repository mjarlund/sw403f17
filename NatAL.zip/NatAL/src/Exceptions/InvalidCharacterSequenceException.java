package Exceptions;

public class InvalidCharacterSequenceException extends Error
{
    public InvalidCharacterSequenceException(String message)
    {
        super(message);
    }
}
