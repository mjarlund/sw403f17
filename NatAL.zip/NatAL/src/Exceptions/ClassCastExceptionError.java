package Exceptions;

public class ClassCastExceptionError extends Error
{
    public ClassCastExceptionError(String message)
    {
        super(message);
    }
}
