package Exceptions;

public class InvalidScopeException extends Error
{
    public InvalidScopeException(String message)
    {
        super(message);
    }
}
