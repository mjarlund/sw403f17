package Exceptions;

public class UndeclaredSymbolException extends Error
{
    public UndeclaredSymbolException(String message)
    {
        super(message);
    }
}
