package Exceptions;

public class InvalidCharacterException extends Error
{
    public InvalidCharacterException(String message)
    {
        super(message);
    }
}
