package DataStructures.AST.NodeTypes;

public enum Modes
{
    DIGITAL,ANALOG
}
