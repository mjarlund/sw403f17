package DataStructures.AST.NodeTypes;

public enum Types
{
    VOID, INT, STRING, FLOAT, CHAR, BOOL, STRUCT, DIGITAL, ANALOG, PIN,LIST
}