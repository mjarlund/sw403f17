package DataStructures.AST.NodeTypes.Declarations;

import DataStructures.AST.AST;

public class Dcl extends AST {
}
