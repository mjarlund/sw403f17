package DataStructures.AST.NodeTypes.Statements;

import DataStructures.AST.AST;

public class Stmt extends AST {
}
