package DataStructures.AST.NodeTypes.Statements;

public class BlockStmt extends Stmt
{
    public BlockStmt ()
    {
        SetValue("BlockStmt");
    }

}
