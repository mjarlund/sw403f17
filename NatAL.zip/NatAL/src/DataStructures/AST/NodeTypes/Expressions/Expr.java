package DataStructures.AST.NodeTypes.Expressions;

import DataStructures.AST.AST;

public class Expr extends AST {
}
