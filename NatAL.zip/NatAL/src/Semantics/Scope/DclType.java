package Semantics.Scope;

public enum DclType {
    Variable,
    Function,
    Struct,
    List
}
