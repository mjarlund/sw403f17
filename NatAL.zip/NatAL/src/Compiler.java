import Visualizing.Visualizer;

public class Compiler
{
    public static void main(String args[])
    {
        Visualizer v = new Visualizer();
        v.Show();
    }
}
