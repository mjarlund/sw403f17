To whom it may concern, 

The included project is a compiler for the NatAL language developed by the study group SW403f17.

To test the compiler yourself, run the main() method in Program.java. 

Have fun!

//SW403f17